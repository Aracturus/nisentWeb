import React from "react";

const Specification = () => {
  return (
    <>
      <div className="container-fluid bg-light pb-lg-2">
        <h1 className="display-5 text-center text-capitalize pt-lg-0 pb-2">
          Specification
        </h1>
      </div>
    </>
  );
};

export default Specification;
