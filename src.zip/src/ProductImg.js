import React from 'react'

const ProductImg = (props) => {
    return (
        <>
            <img src= {props.src} height = "700"  width = "100%"  className = {ProductImg}/>
        </>
    )
}

export default ProductImg
